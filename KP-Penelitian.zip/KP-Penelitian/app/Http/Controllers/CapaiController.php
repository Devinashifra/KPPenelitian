<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CapaiController extends Controller
{
    public function index(){
        return view ('mahasiswa.capaian');
    }
}
