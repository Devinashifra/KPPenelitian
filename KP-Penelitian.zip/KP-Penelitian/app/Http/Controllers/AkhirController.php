<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AkhirController extends Controller
{
    public function index(){
        return view('mahasiswa.laporakh');
    }
}
