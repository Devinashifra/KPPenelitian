<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KP Penelitian</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body,nav{
            background-image: url('/img/ruang2.png'); 
            background-size: cover;
        }
        .row{
            padding: 125px 0;
                text-align: center;
        }
    </style>

    <nav class="navbar sticky-top bg-body-tertiary" style="--bs-breadcrumb-divider: '>'; font-color: #000000" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/welcome')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('/alurdanpanduan')); ?>">Alur dan Panduan</a></li>
            <li class="breadcrumb-item active" aria-current="page">JSS</li>
            <li class="breadcrumb-item active" aria-current="page">Magang</li>
            <li class="breadcrumb-item active" aria-current="page">Laporan</li>
        </ol>
    </nav>
</head>
<body>
    <div class="row sm:justify-center items-center pt-6 sm:pt-0">
        <div class="col-sm-3">
            <div class="card text-center">
                <img src="<?php echo e(asset ('img')); ?>/alur.png" class="card-img-top" alt="" >
                    <div class="card-body">
                        <a href="https://jss.jogjakota.go.id/v4/register" class="btn"><b>Registrasi Akun JSS</b></a>
                    </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card text-center">
                <img src="<?php echo e(asset ('img')); ?>/alur.png" class="card-img-top" alt="" >
                    <div class="card-body">
                        <a href="https://help.jogjakota.go.id/livechat.html?channel=oaTnqVdEL9xvWA8VigoLpDgk" class="btn"><b>Konsultasi</b></a>
                    </div>
            </div>
        </div>
    </div>
</body>
    <!--Footer-->
    <footer class="p-3 mt-3" style=" background-color: #72826A">
        <div class="footer">
            <div class="container" style="bottom: 5px; color: white;">
                    <div clas="col">
                        <p>Dinas Komunikasi, Informatika dan Persandian </p>
                        <p>Jl. Kenari No. 56 Yogyakarta Telp. </p>
                        <p>(0274) 515865, 561270 </p>
                    </div>
            </div>
        </div>
    </footer>
</html><?php /**PATH C:\laragon\www\KP-Penelitian\resources\views/jss.blade.php ENDPATH**/ ?>