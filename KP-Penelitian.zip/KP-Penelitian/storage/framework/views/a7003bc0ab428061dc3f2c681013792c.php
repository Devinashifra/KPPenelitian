<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KP Penelitian</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Caprasimo">

    <style>
        body{
           
            background-color: #D2DFBD;
        }
        .row{
            padding: 125px 0;
            text-align: center;
            justify-content: center;
            align-items: center;
        }
        .card{
            width: 180px;
            height: 240px;
        }
        .card-img-top {
            width: 180px;
            height: 150px;
            justify: center;
            align-items: center;
            padding-top: 20px;
            padding-left: 20px;
            padding-right: 20px;
            /* top: 75%;
            left: 75%;
            translate: -50% -50%; */
        }
    </style>

    
</head>
<body>
    <br>
    <br>
    <br>
    <br>
    <br>
    <div class="row sm:justify-center items-center pt-6 sm:pt-0">
        <div class="col-sm-3">
            <div class="card text-center">
                <img src="<?php echo e(asset ('icon')); ?>/lapkem.png" class="card-img-top" alt="" >
                    <div class="card-body" >
                        <a href="<?php echo e(url('/capaian')); ?>" class="btn"><b>Laporan Kemajuan</b></a>
                    </div>
                </div>
            </div>
        
        <div class="col-sm-3">
            <div class="card text-center">
                <img src="<?php echo e(asset ('icon')); ?>/laporakh.png" class="card-img-top" alt="">
                    <div class="card-body">
                        <a href="<?php echo e(url('/laporanakhir')); ?>" class="btn"><b>Laporan Akhir Periode</b></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</body>
    
</html>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\KP-Penelitian\resources\views/dashboard.blade.php ENDPATH**/ ?>