<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KP Penelitian</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Caprasimo">

    <style>
        body,nav{
            background-image: url('/img/ruang2.png'); 
            background-size: cover;
            /* background-repeat: no-repeat; */
            background-position: center;
        }
        .row{
            padding: 125px 0;
            text-align: center;
            font-family: Caprasimo;
            justify-content: center;
            align-items: center;
        }
        body{
            text-indent: 30px;
        }

    </style>

    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand">KP Penelitian</a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item" style="font-weight: bold;">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="nav-item" style="font-weight: bold;">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('/alurdanpanduan')); ?>">Alur dan Panduan</a>
                    </li>
                    <li class="nav-item" style="font-weight: bold;">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('/magang')); ?>">Magang</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</head>
<body>
    <h4>Form Pendaftaran</h4>
    <h6>di Bidang Sistem Informasi dan Statistik Diskominfosan Yk</h6>

    <br>

    <div class="d-grid gap-3 d-md-block">
        <button class="btn btn-outline-dark" type="button">Ketentuan</button>
        <button class="btn btn-outline-dark" type="button">Alur Pendaftaran</button>
        <button class="btn btn-outline-dark" type="button">Form Daftar</button>
    </div>
    
</body>

    <footer style=" background-color: #72826A">
        <div class="footer">
            <div class="container" style="color: white;">
                <div class="row">
                    <div clas="col">
                        <p>Dinas Komunikasi, Informatika dan Persandian </p>
                        <p>Jl. Kenari No. 56 Yogyakarta Telp. </p>
                        <p>(0274) 515865, 561270 </p>
            
                    </div>
                </div>
            </div>
        </div>
    </footer>
</html><?php /**PATH C:\laragon\www\KP-Penelitian\resources\views/magang/pendaftaran.blade.php ENDPATH**/ ?>