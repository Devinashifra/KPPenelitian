<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KP Penelitian</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body,nav{
            background-image: url('/img/ruang2.png'); 
            background-size: cover;
        }
        .row{
            padding: 125px 0;
                text-align: center;
        }
    </style>

    <nav class="navbar sticky-top bg-body-tertiary" style="--bs-breadcrumb-divider: '>'; font-color: #000000" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/welcome')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('/alurdanpanduan')); ?>">Alur dan Panduan</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('/jss')); ?>">JSS</a></li>
            <li class="breadcrumb-item"><a href="#">Magang</a></li>
            <li class="breadcrumb-item active" aria-current="page">Laporan</li>
        </ol>
    </nav>
</head>
<body>
    <div class="row">
        <div class="col-sm-6 col-lg-6 mb-4">
            <div class="card text-center">
                <img src="<?php echo e(asset ('img')); ?>/alur.png" class="card-img-top" alt="" >
                    <div class="card-body">
                        <a href="#" class="btn"><b>Pengumpulan Laporan (Akhir Periode)</b></a>
                    </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-6 mb-4">
            <div class="card text-center">
                <img src="<?php echo e(asset ('img')); ?>/alur.png" class="card-img-top" alt="" >
                    <div class="card-body">
                        <a href="#" class="btn"><b>Pelaporan Kemajuan (Capaian per Pertemuan)</b></a>
                    </div>
            </div>
        </div>
    </div>
</body>
    <!--Footer-->
    <footer class="p-3 mt-3" style=" background-color: #72826A">
        <div class="footer">
            <div class="container" style="bottom: 5px; color: white;">
                    <div clas="col">
                        <p>Dinas Komunikasi, Informatika dan Persandian </p>
                        <p>Jl. Kenari No. 56 Yogyakarta Telp. </p>
                        <p>(0274) 515865, 561270 </p>
                    </div>
            </div>
        </div>
    </footer>
</html><?php /**PATH C:\laragon\www\KP-Penelitian\resources\views/laporan.blade.php ENDPATH**/ ?>