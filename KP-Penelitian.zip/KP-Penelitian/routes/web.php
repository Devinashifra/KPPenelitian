<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\WelcomeController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\FormdafController;
use App\Http\Controllers\AkhirController;
use App\Http\Controllers\CapaiController;
use App\Models\Daftar;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('index');
});

// Route::get('/welcome', function () {
//     return view('welcome');
// });

// Route::get('/welcome', [WelcomeController::class, 'index'])->name('welcome.index');
Route::get('/alurdanpanduan', [HomeController::class, 'indexap'])->name('alurdanpanduan');
Route::get('/magang', [HomeController::class, 'indexmag'])->name('magang');
Route::get('/magang/pendaftaran', [HomeController::class, 'indexpend'])->name('pendaftaran');
Route::get('/magang/form', [FormdafController::class, 'indexform'])->name('form');
Route::get('/laporanakhir',[AkhirController::class, 'index'])->name('laporakh');
Route::get('/capaian',[CapaiController::class, 'index'])->name('capaian');

Route::post('/magang/form', [FormdafController::class, 'store'])->name('daftar.kp');

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('/admin', function () {
    return view('admin.index'); }) -> middleware('checkRole:admin');
Route::get('/dashboard', function () {
    return view('dashboard'); }) -> middleware('checkRole:mahasiswa,admin')->name('dashboard');
// Route::middleware('admin')->group(function() {
//     Route::get('/user', [UserController::class, 'index'])->name('user.index');
//     Route::delete('/user/{user}', [UserController::class, 'destroy'])->name('user.destroy');
//     Route::patch('/user/{user}/makeadmin', [UserController::class, 'makeadmin'])->name('user.makeadmin');
//     Route::patch('/user/{user}/removeadmin', [UserController::class, 'removeadmin'])->name('user.removeadmin');
// });

require __DIR__.'/auth.php';
 